package juego.util;

import java.lang.Exception;

/**
 * Método que recoge las excepciones si las coordenadas son incorrectas.
 * 
 * @author Alex Tomé, Francisco Medel
 * @since JDK 11
 * @version 1.0
 */
public class CoordenadasIncorrectasException extends Exception{
	
	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructor.
	 */
	public CoordenadasIncorrectasException() {
		super();
	}
	
	/**
	 * Constructor.
	 * @param message mensaje
	 */
	public CoordenadasIncorrectasException(String message) {
		super(message);
	}
	
	/**
	 * Constructor.
	 * @param clause clause
	 */
	public CoordenadasIncorrectasException(Throwable clause) {
		super(clause);
	}
	
	/**
	 * Constructor.
	 * @param message mensaje
	 * @param clause clause
	 */
	public CoordenadasIncorrectasException(String message, Throwable clause) {
		super(message,clause);
	}
	
}