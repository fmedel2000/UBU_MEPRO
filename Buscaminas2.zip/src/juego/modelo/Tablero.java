package juego.modelo;
import java.util.Random;
import juego.control.DistanciaChebyshev;
import juego.modelo.Celda;
import juego.util.CoordenadasIncorrectasException;
import juego.util.Sentido;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase del tablero del juego. Instancia las celdas en un tablero 8*8 y coloca las minas.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.5
 */
public class Tablero{
	
	/**
	 * NUMERO_FILAS.
	 */
	public static final int NUMERO_FILAS = 8;
	
	/**
	 * NUMERO_COLUMNAS.
	 */
	public static final int NUMERO_COLUMNAS = 8;
	
	/**
	 * Celdas.
	 */
	
	private List<List<Celda>> celdas;
	
	/**
	 * Método constructor del tablero.
	 */
	public Tablero(){
		
		//Creamos el array de celdas con arraylist
		celdas = new ArrayList<List<Celda>>();
		
		//Creamos las celdas
		List<Celda> c1=new ArrayList<Celda>();
		List<Celda> c2=new ArrayList<Celda>();
		List<Celda> c3=new ArrayList<Celda>();
		List<Celda> c4=new ArrayList<Celda>();
		List<Celda> c5=new ArrayList<Celda>();
		List<Celda> c6=new ArrayList<Celda>();
		List<Celda> c7=new ArrayList<Celda>();
		List<Celda> c8=new ArrayList<Celda>();
		
		for(int i=0;i<NUMERO_FILAS;i++) {
			c1.add(new Celda(0,i));
			c2.add(new Celda(1,i));
			c3.add(new Celda(2,i));
			c4.add(new Celda(3,i));
			c5.add(new Celda(4,i));
			c6.add(new Celda(5,i));
			c7.add(new Celda(6,i));
			c8.add(new Celda(7,i));
		}
		
		//Añadimos al array de celdas
		celdas.add(c1);
		celdas.add(c2);
		celdas.add(c3);
		celdas.add(c4);
		celdas.add(c5);
		celdas.add(c6);
		celdas.add(c7);
		celdas.add(c8);
		
	}
	
	/**
	 * Método que hace un clon del tablero.
	 * 
	 * @return clon del tablero
	 */
	public Tablero clonar() {
		Tablero clon = new Tablero();
		
		for(int fila=0; fila < NUMERO_FILAS; fila++) {
			for(int columna=0; columna < NUMERO_COLUMNAS; columna++) {
				clon.celdas.get(fila).set(columna, celdas.get(fila).get(columna).clonar());
			}
		}
		
		return clon;
	}
	
	/**
	 * Método que clona una celda en las coordenadas correspondientes.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @return clon clon de la celda
	 * @throws CoordenadasIncorrectasException excepción si no está en los límites del tablero
	 */
	public Celda clonarCelda(int fila, int columna) throws CoordenadasIncorrectasException{
		//Comprobamos que está dentro de los límites del tablero.
		try {
			if((columna >= NUMERO_COLUMNAS || columna < 0) || (fila >= NUMERO_FILAS || fila < 0)) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else {
				Celda clon = celdas.get(fila).get(columna).clonar();
				return clon;
			}
		}catch(CoordenadasIncorrectasException e) {
			throw new CoordenadasIncorrectasException("No se puede clonar la celda",e);
		}
	}
	
	/**
	 * Método que clona las celdas a un array.
	 * 
	 * @return listaclon lista de celdas clonadas
	 */
	public List<Celda> clonarCeldas() {
		//Hacemos un array de celdas y las almacenamos.
		List<Celda> clon = new ArrayList<>();
		
		for(int fila=0; fila < NUMERO_FILAS; fila++) {
			for(int columna=0; columna < NUMERO_COLUMNAS; columna++) {	
				clon.add(celdas.get(fila).get(columna).clonar());
				//clon[8*fila+columna] = celdas[fila][columna].clonar();
			}
		}
		return clon;
	}
	
	/**
	 * Método que coloca las minas aleatoriamente, sin comprobar semilla.
	 */
	public void colocarMinas() {
		for(int i = 0; i < 10; i++) {	
			//Generamos las coordenadas aleatorias.
			int fila = (int) (Math.random()*8);
		    int columna =(int) (Math.random()*8);
		    celdas.get(fila).get(columna).colocarMina();
		    
		    for(Sentido p : Sentido.values()) {
	    		//Creamos dos enteros con la fila y columna de la celda y sus respectivos desplazamientos del sentido.
                int x = celdas.get(fila).get(columna).obtenerFila() + p.obtenerDesplazamientoEnFilas();
                int y = celdas.get(fila).get(columna).obtenerColumna() + p.obtenerDesplazamientoEnColumnas();
                
                //Para establecer las minas adyacentes, comprobamos que está en los límites, que está oculta y no tiene mina.
                //Si es así, establecemos el número de minas adyacentes.
                if ( ((0 <= x && x <= 7) && (0 <= y && y <= 7)) && celdas.get(x).get(y).estaOculta() && !celdas.get(x).get(y).tieneMina()) {
                    int numeroMinasAdyacentes = celdas.get(x).get(y).obtenerNumeroMinasAdyacentes();
                    celdas.get(x).get(y).establecerNumeroMinasAdyacentes(numeroMinasAdyacentes+1);
                }
            }
		}
		
	}
	
	/**
	 * Método que coloca las minas en el tablero.
	 * 
	 * @param inicio celda de origen
	 * @param distancia distancia de chebyshev
	 * @param rd numero aleatorio
	 */
	public void colocarMinas(Celda inicio, DistanciaChebyshev distancia, Random rd) {
		//Creamos un bucle con límite 10 para que se coloquen las 10 minas.
		for(int i = 0; i < 10; i++) {
			
			//Generamos las coordenadas aleatorias.
			int fila = rd.nextInt(8);
		    int columna =rd.nextInt(8);
		    
		    //Comprobamos que se puede colocar la mina si la celda origen no es la de destino, no tiene mina y la distancia de chebyshev es mayor a 1.
		    if (celdas.get(fila).get(columna) != inicio && !celdas.get(fila).get(columna).tieneMina() && distancia.calcular(inicio,celdas.get(fila).get(columna)) > 1) {
		    	celdas.get(fila).get(columna).colocarMina();
		    	//Recorremos en todos los sentidos.
		    	for(Sentido p : Sentido.values()) {
		    		//Creamos dos enteros con la fila y columna de la celda y sus respectivos desplazamientos del sentido.
                    int x = celdas.get(fila).get(columna).obtenerFila() + p.obtenerDesplazamientoEnFilas();
                    int y = celdas.get(fila).get(columna).obtenerColumna() + p.obtenerDesplazamientoEnColumnas();
                    
                    //Para establecer las minas adyacentes, comprobamos que está en los límites, que está oculta y no tiene mina.
                    //Si es así, establecemos el número de minas adyacentes.
                    if ( ((0 <= x && x <= 7) && (0 <= y && y <= 7)) && celdas.get(x).get(y).estaOculta() && !celdas.get(x).get(y).tieneMina()) {
                        int numeroMinasAdyacentes = celdas.get(x).get(y).obtenerNumeroMinasAdyacentes();
                        celdas.get(x).get(y).establecerNumeroMinasAdyacentes(numeroMinasAdyacentes+1);
                    }
                }
		    }else {
		    	//Si no se coloca una mina, volvemos atrás en el bucle para reintentar y colocar las 10 minas.
		    	i--;
		    }
		}

    }
	
	/**
	 * Método que cuenta las celdas marcadas (banderas).
	 * 
	 * @return banderas
	 */
	public int contarBanderas() {
		
		int banderas = 0;
		for (int i= 0; i < NUMERO_FILAS ; i++) {
            for (int j= 0; j < NUMERO_COLUMNAS ; j++) {
            	//Si la celda está marcada, aumentamos el contador de banderas.
            	if(celdas.get(i).get(j).estaMarcada()) {
    				banderas++;
            	}			
			}
		}
		return banderas;
	}
	
	/**
	 * Método que cuenta las celdas que tienen de estado descubiertas.
	 * 
	 * @return descubiertas
	 */
	public int contarCeldasDescubiertas() {
		
		int descubiertas = 0;	
		for (int i= 0; i < NUMERO_FILAS ; i++) {
            for (int j= 0; j < NUMERO_COLUMNAS ; j++) {
            	//Si la celda está descubierta, aumentamos el contador de descubiertas.
            	if(celdas.get(i).get(j).estaDescubierta()) {
            		descubiertas++;
            	}	
			}
		}	
		return descubiertas;
	}
	
	/**
	 * Método que cuenta las minas.
	 * 
	 * @return contador
	 */
	public int contarMinas() {
		int contador = 0;
		
		for (int i= 0; i < NUMERO_FILAS ; i++) {
            for (int j= 0; j < NUMERO_COLUMNAS ; j++) {
            	//Si la celda tiene mina, aumentamos el contador de minas.
                if(celdas.get(i).get(j).tieneMina()) {
                	contador++;
                }
            }
        }
		return contador;
	}
	
	/**
	 * Método que devuelve el número de celdas descubiertas que contienen minas.
	 * 
	 * @return contador
	 */
	public int contarMinasExplotadas() {
		
		int contador = 0;
		
		for (int i= 0; i < NUMERO_FILAS ; i++) {
            for (int j= 0; j < NUMERO_COLUMNAS ; j++) {
            	//Si la celda tiene mina y además está descubierta, aumentamos el contador.
                if(celdas.get(i).get(j).tieneMina() && celdas.get(i).get(j).estaDescubierta()) {
                	contador++;
                }
            }
        }
		return contador;
	}
	
	/**
	 * Método que descubre las celdas.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @throws CoordenadasIncorrectasException excepción si no está en los límites del tablero 
	 */
	public void descubrir(int fila, int columna) throws CoordenadasIncorrectasException {
		//Comprobamos si está dentro de los límites del tablero y descubrimos.
		try {
			if((columna >= NUMERO_COLUMNAS || columna < 0) || (fila >= NUMERO_FILAS || fila < 0)) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else {
				celdas.get(fila).get(columna).establecerSiguienteEstadoDescubrir();
			}
		}catch(CoordenadasIncorrectasException e) {
			throw new CoordenadasIncorrectasException("No se puede marcar o desmarcar la celda",e);
		}
			
	    if(celdas.get(fila).get(columna).obtenerNumeroMinasAdyacentes() == 0){
	    	//Recorremos en todos los sentidos.
	        for(Sentido s : Sentido.values()) {
	        	//Creamos dos enteros para las filas y las columnas desplazadas a partir de la celda y el desplazamiento del sentido.
	        	int filaDesp = celdas.get(fila).get(columna).obtenerFila() + s.obtenerDesplazamientoEnFilas();
			    int columnaDesp = celdas.get(fila).get(columna).obtenerColumna() + s.obtenerDesplazamientoEnColumnas();
			     
			    //Si las minas adyacentes son igual a cero, hacemos recursividad. Si no, directamente establecemos el siguiente estado.
			    //Para ello también se comprueba que la celda está oculta y no tiene mina.
			    if ( ((filaDesp < 8 && filaDesp >= 0) && (columnaDesp < 8 && columnaDesp >= 0)) && celdas.get(filaDesp).get(columnaDesp).estaOculta() && (!celdas.get(filaDesp).get(columnaDesp).tieneMina() ) && (celdas.get(filaDesp).get(columnaDesp).obtenerNumeroMinasAdyacentes() > 0) ) {
			    	celdas.get(filaDesp).get(columnaDesp).establecerSiguienteEstadoDescubrir();
			    }
			    if ( ((filaDesp < 8 && filaDesp >= 0) && (columnaDesp < 8 && columnaDesp >= 0)) && celdas.get(filaDesp).get(columnaDesp).estaOculta() && (!celdas.get(filaDesp).get(columnaDesp).tieneMina() ) && (celdas.get(filaDesp).get(columnaDesp).obtenerNumeroMinasAdyacentes() == 0) ) {
			        celdas.get(filaDesp).get(columnaDesp).establecerSiguienteEstadoDescubrir();
			        	descubrir(filaDesp,columnaDesp);
			    }
	        }
	    }
        
	}
	
	/**
	 * Método que cambia el estado de la celda de marcada a desmarcada o viceversa.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @throws CoordenadasIncorrectasException excepción si no está en los límites del tablero
	 */
	public void marcarDesmarcar(int fila, int columna) throws CoordenadasIncorrectasException{
		try {
			if((columna >= NUMERO_COLUMNAS || columna < 0) || (fila >= NUMERO_FILAS || fila < 0)) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else {
				celdas.get(fila).get(columna).establecerSiguienteEstadoMarcar();
			}
		}catch(CoordenadasIncorrectasException e) {
			throw new CoordenadasIncorrectasException("No se puede marcar o desmarcar la celda",e);
		}
		
	}
	
	/**
	 * Método que devuelve la referencia a la celda del tablero.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @return celdas celdas
	 * @throws CoordenadasIncorrectasException excepción si no está en los límites del tablero
	 */
	Celda obtenerCelda(int fila, int columna) throws CoordenadasIncorrectasException {
		//Comprobamos que está dentro de los límites y si es así, devolvemos la celda.
		try {
			if(fila >= NUMERO_FILAS || columna >= NUMERO_COLUMNAS || fila < 0 || columna < 0) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else {
				return celdas.get(fila).get(columna);
			}	
		}catch(CoordenadasIncorrectasException e){
			throw new CoordenadasIncorrectasException("No se puede obtener la celda",e);
		}
	}
	
	/**
	 * Método que obtiene el número de columnas.
	 * 
	 * @return NUMERO_COLUMNAS
	 */
	public int obtenerNumeroColumnas() {
		return NUMERO_COLUMNAS;
	}

	/**
	 * Método que obtiene el número de filas.
	 * 
	 * @return NUMERO_FILAS
	 */
	public int obtenerNumeroFilas() {
		return NUMERO_FILAS;
	}
	
	/**
	 * Método que obtiene la solución del tablero en cadena de texto.
	 * 
	 * @return t Tablero en cadena de texto
	 */
	public String obtenerSolucion() {
		//Hacemos un doble bucle para hacer print de todo el tablero.
		String t="";
		for(int i=0;i<=7;i++) {
			t=t+(i);
			for (int j=0;j<=7;j++){
				//Obtenemos el texto de la solución de las celdas.
				t=t+celdas.get(i).get(j).obtenerTextoSolucion();
			}
			t=t+"\n";
		}
		t=t+"  0  1  2  3  4  5  6  7";
		return t;
	}
	
	/**
	 * Método que obtiene el tablero en cadena de texto.
	 * 
	 * @return t Tablero en cadena de texto
	 */
	public String toString() {
		//Hacemos un doble bucle para hacer print de todo el tablero.
		String t="";
		for(int i=0;i<=7;i++) {
			t=t+(i);
			for (int j=0;j<=7;j++){
				//Obtenemos el texto del estado de las celdas.
				t=t+celdas.get(i).get(j).obtenerTextoEstado();
			}
			t=t+"\n";
		}
		t=t+"  0  1  2  3  4  5  6  7";
			return t;
	}
}
