package musica;

/**
 * Clase Cuerda.
 * 
 * @author Francisco Medel Molinero
 * @version 1.0
 */
public class Cuerda extends Instrumento {
	public Cuerda(float precio) {
		super(precio);
	}
	
	@Override
	public void tocar(Nota nota) {		
		System.out.printf("Cuerdo.tocar(): %s%n", nota.toString());
	}

	@Override
	public String toString() {
		return "[" + this.consultarPrecio() +  ":Viento]";
	}
}
