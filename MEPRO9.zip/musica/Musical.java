package musica;
/**
 * Interfaz que se implementa al instrumento.
 * 
 * @author Francisco Medel Molinero
 * @version 1.0
 */
public interface Musical {
	void tocar(Nota nota);
}
