package genericidad;

import musica.Cuerda;
import musica.Metal;
import musica.Musical;
import musica.Nota;
import musica.Viento;

/**
 * @author Francisco Medel
 * @version 1.0
 * */
public class Principal {
	
	public static void main(String[] args) {
		//Lista<Nota> notasMusicales = new Lista<Nota>(10);
		//rellenarNotasMusicales(notasMusicales);
		//mostrarNotasMusicales(notasMusicales);
		//mostrar(notasMusicales);
		
		Lista<Musical> instrumentosMusicales = new Lista<Musical>(10);
		rellenarInstrumentosMusicales(instrumentosMusicales);
		//mostrarInstrumentosMusicales(instrumentosMusicales);
		mostrar(instrumentosMusicales);
	}
	
	//EL INTERROGANTE REPRESENTA UN OBJETO DEL TIPO MUSICAL
	private static void mostrar(Lista<? extends Musical> lista) {
		for(int i=0;i<lista.size();i++) {
			System.out.println(lista.get(i).tocar(Nota.DO));
		}
	}
	private static void rellenarInstrumentosMusicales(Lista<Musical> instrumentos) {
		for(int i=0; i < instrumentos.size();i++) {
			int aleatorio = (int)(Math.random()*3);
			Musical musical= null;
			switch(aleatorio) {
			case 0: musical = new Viento(10.0F);
				break;
			case 1: musical = new Cuerda(10.0F);
			break;
			case 2: musical = new Metal(10.0F);
			break;
			
			}
			instrumentos.set(i, musical);
		}
	}
	
	
	
	private static void mostrarInstrumentosMusicales(Lista<Musical> instrumentos) {
		for(int i=0; i < instrumentos.size(); i++) {
			Musical musical = instrumentos.get(i);
			System.out.println(musical.toString());
		}
	}
	
	private static void rellenarNotasMusicales(Lista<Nota> lista) {
		for(int i=0; i < lista.size();i++) {
			int aleatoria = (int)(Math.random()*Nota.values().length);
			Nota notaAleatoria = Nota.values()[aleatoria];
			lista.set(i, notaAleatoria);
		}
	}
	
	
	
	private static void mostrarNotasMusicales(Lista<Nota> lista) {
		for(int i=0; i < lista.size(); i++) {
			System.out.println(lista.get(i).toString());
		}
	}
}
