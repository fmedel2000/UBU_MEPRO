package genericidad;
import java.util.ArrayList;
import musica.Musical;
import java.util.List;
/**
 * @author Francisco Medel
 * @version 1.0
 * */
public class Lista<E extends Musical>{//parametro generico formal
	private List<E> arrayImplementacion;
	public Lista(int numero) {
		arrayImplementacion= new ArrayList<E>();
		for (int i = 0 ; i < numero ; i++) { // suponemos una reserva de n�mero
			arrayImplementacion.add(null);
			}
	}
	/**
	 * M�todo que establece
	 * @param elemento
	 * @param posicion
	 */
	public void set(E elemento, int posicion) {
		if(posicion >= 0 && posicion < size()) {
		arrayImplementacion.set(posicion, elemento);
		}
	}
	/**
	 * Metodo que obtiene
	 * @param posicion
	 * @return
	 */
	public E get(int posicion) {
		if(posicion >= 0 && posicion < size()) {
		return arrayImplementacion.get(posicion);
		}
		return null;
	}
	/**
	 * Metodo que calcula el tama�o
	 * @return
	 */
	public int size() {
		return arrayImplementacion.size();
	}
}
