package juego.modelo;


/**
 * Clase de las celdas del juego.
 * 
 * @author Francisco Medel, Alex Tomé
 * @version 1.2
 */
public class Celda {
	
	/**
	 * TEXTO_MINA.
	 */
	protected static String TEXTO_MINA = " - ";
	
	/**
	 * numeroMinas.
	 */
	static int numeroMinas;
	
	/**
	 * Estado.
	 */
	private Estado estado;
	
	/**
	 * Celda.
	 */
	private Celda celda;
	
	/**
	 * Fila.
	 */
	private int fila;
	
	/**
	 * Columna.
	 */
	private int columna;
	
	/**
	 * Método constructor de la celda.
	 * 
	 * @param fila
	 * @param columna
	 */
	public Celda(int fila, int columna) {
		
		this.fila = fila;
		this.columna = columna;
		estado = Estado.OCULTA;
		numeroMinas = 0;
	}
	
	/**
	 * Método que clona una celda independiente.
	 * 
	 * @return clon
	 */
	public Celda clonar() {
		
		Celda clon = new Celda(fila, columna);
		clon.numeroMinas = this.numeroMinas;
		clon.estado = this.estado;
		return clon;
	}
	
	/**
	 * Método que coloca la mina.
	 */
	void colocarMina() {
		numeroMinas = -1;
	}
	
	/**
	 * Método que establece el número de minas adyacentes.
	 * 
	 * @param numeroMinas
	 */
	void establecerNumeroMinasAdyacentes(int numeroMinas) {
		this.numeroMinas = numeroMinas;
	}
	
	/**
	 * Método que cambia el estado de la celda al descubrirla.
	 */
	void establecerSiguienteEstadoDescubrir() {
		
		if(estaOculta()) {
			estado = Estado.DESCUBIERTA;
		}
	}
	
	/**
	 * Método que cambia el estado de la celda al marcarla.
	 */
	void establecerSiguienteEstadoMarcar() {
		if(estaOculta()) {
			estado = Estado.MARCADA;
		}else if(estaMarcada()) {
			estado = Estado.OCULTA;
		}
	}
	
	/**
	 * Método que comprueba que el estado de la celda es descubierta.
	 * 
	 * @return true si lo está o false si no
	 */
	public boolean estaDescubierta() {
		if(estado == Estado.DESCUBIERTA) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Método que comprueba que el estado de la celda es marcada.
	 * 
	 * @return true si lo está o false si no
	 */
	public boolean estaMarcada() {
		if(estado == Estado.MARCADA) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Método que comprueba que el estado de la celda es oculta.
	 * 
	 * @return true si lo está o false si no
	 */
	public boolean estaOculta() {
		
		if(estado == Estado.OCULTA) {
			return true;
		}else {
			return false;
		}
		
	}
	
	/**
	 * Método que obtiene la columna.
	 * 
	 * @return columna
	 */
	public int obtenerColumna() {
		return columna;
	}
	
	/**
	 * Método que obtiene la fila.
	 * 
	 * @return fila
	 */
	public int obtenerFila() {
		return fila;
	}
	
	/**
	 * Método que obtiene el número de minas adyacentes.
	 * 
	 * @return numeroMinas
	 */
	public int obtenerNumeroMinasAdyacentes() {
		return numeroMinas;
	}
	
	/**
	 * Método que genera una cadena de texto del estado.
	 * 
	 * @return TEXTO_MINA
	 */
	public String obtenerTextoEstado() {
		
		if(estaDescubierta()) {
			if(tieneMina()) {
				return TEXTO_MINA = " M ";
			}else if(obtenerNumeroMinasAdyacentes() != 0){
				int X = obtenerNumeroMinasAdyacentes();
				return TEXTO_MINA = " " + X +" ";
			}else if(obtenerNumeroMinasAdyacentes() == 0) {
				return TEXTO_MINA = " . ";
			}
		}else if(estaOculta()){
			return TEXTO_MINA = " - ";
		}else if(estaMarcada()){
			return TEXTO_MINA = " P ";
		}
		
		return TEXTO_MINA = " - ";
	}
	
	/**
	 * Método que obtiene en cadena de texto la solución.
	 * 
	 * @return TEXTO_MINA
	 */
	public String obtenerTextoSolucion() {
		
		if(tieneMina()) {
			return TEXTO_MINA = " M ";
		}else {
			if(obtenerNumeroMinasAdyacentes() != 0){
				int X = obtenerNumeroMinasAdyacentes();
				return TEXTO_MINA = " " + X +" ";
			}else if(obtenerNumeroMinasAdyacentes() == 0) {
				return TEXTO_MINA = " - ";
			}
		}
		
		return TEXTO_MINA = " - ";
		
	}
	
	/**
	 * Método que comprueba si dos celdas tienen mismas coordenadas.
	 * 
	 * @param celda
	 * @return true si las tienen o false si no
	 */
	public boolean tieneCoordenadasIguales(Celda celda) {
		if(celda.fila == this.fila && celda.columna == this.columna) {
    		return true;
    	}else {
    		return false;
    	}
	}
	
	/**
	 * Método que comprueba si una celda tiene mina
	 * 
	 * @return true si tiene, false si no
	 */
	public boolean tieneMina() {
		
		if(numeroMinas == -1) {
			return true;
		}else {
			return false;
		}
		
	}

	/**
	 * Método que devuelve una cadena de texto.
	 * 
	 * @return texto de coordenadas, número de minas adyacentes y estado de una celda
	 */
	public String toString() {
		return "["+"("+fila+","+columna+")"+"-"+obtenerNumeroMinasAdyacentes()+"-"+estado+"]";
	}

	/**
	 * Método hashcode de la celda.
	 * 
	 * @return result
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((celda == null) ? 0 : celda.hashCode());
		result = prime * result + columna;
		result = prime * result + ((estado == null) ? 0 : estado.hashCode());
		result = prime * result + fila;
		return result;
	}

	/**
	 * Método equals de la celda.
	 * 
	 * @return true o false
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Celda other = (Celda) obj;
		if (celda == null) {
			if (other.celda != null)
				return false;
		} else if (!celda.equals(other.celda))
			return false;
		if (columna != other.columna)
			return false;
		if (estado != other.estado)
			return false;
		if (fila != other.fila)
			return false;
		return true;
	}


	
}
