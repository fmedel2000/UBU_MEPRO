package juego.modelo;
/**
 * Clase de los estados de las celdas del juego.
 * 
 * @author Francisco Medel, Alex Tomé
 * @version 1.0
 */
public enum Estado {
	
	MARCADA('P'), DESCUBIERTA('0'), OCULTA('-');
	
	/**
	 * Letra.
	 */
	private char letra;
	
	/**
	 * Método constructor del estado.
	 * 
	 * @param letra
	 */
	private Estado(char letra) {
		this.letra = letra;
	}
	
	/**
	 * Método que obtiene la letra.
	 * 
	 * @return letra
	 */
	public char obtenerLetra() {
		return letra;
	}
}
