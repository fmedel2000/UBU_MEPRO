package juego.modelo;
import juego.control.DistanciaChebyshev;
import juego.modelo.Celda;
import juego.modelo.Estado;
import juego.util.Sentido;

/**
 * 
 * @author Francisco Medel, Alex Tomé
 * @version 1.2
 */
public class Tablero {
	
	/**
	 * NUMERO_FILAS.
	 */
	public static final int NUMERO_FILAS = 8;
	
	/**
	 * NUMERO_COLUMNAS.
	 */
	public static final int NUMERO_COLUMNAS = 8;
	
	/**
	 * Celdas.
	 */
	private Celda[][] celdas;
	
	private Celda tablero[][];
	
	private Estado estado;
	
	Estado[] values = Estado.values();
	
	private Celda celda;
	
	/**
	 * Método constructor del tablero.
	 */
	public Tablero(){
		celdas = new Celda[NUMERO_FILAS][NUMERO_COLUMNAS];
		
		for(int fila=0; fila < NUMERO_FILAS; fila++) {
			for(int columna=0; columna < NUMERO_COLUMNAS; columna++) {
				celdas[fila][columna] =  new Celda(fila, columna);
			}
		}
	}
	
	/**
	 * Método que hace un clon del tablero.
	 * 
	 * @return clon
	 */
	public Tablero clonar() {
		Tablero clon = new Tablero();
		return clon;
	}
	
	/**
	 * Método que clona una celda en las coordenadas correspondientes.
	 * 
	 * @param fila
	 * @param columna
	 * @return clon o null si sobrepasa los límites del tablero la coordenada correspondiente
	 */
	public Celda clonarCelda(int fila, int columna) {
		
		if(columna < NUMERO_COLUMNAS && fila < NUMERO_FILAS) {
			Celda clon = new Celda(fila, columna);
			return clon;
		}else {
			return null;
		}
		
	}
	
	/**
	 * Método que clona las celdas a un array.
	 * 
	 * @return clon
	 */
	public Celda[] clonarCeldas() {
		
		Celda[] clon;
		for(int fila=0; fila < NUMERO_FILAS; fila++) {
			for(int columna=0; columna < NUMERO_COLUMNAS; columna++) {
				clon = new Celda[fila];
			}
		}
		
		return clon = null;
	}
	
	public void colocarMinas(Celda inicio, DistanciaChebyshev distancia, Random rd) {
		
	}
	
	/**
	 * Método que cuenta las celdas marcadas (banderas).
	 * 
	 * @return banderas
	 */
	public int contarBanderas() {
		
		int banderas = 0;
		
		while(celda.estaMarcada()) {
			banderas++;
		}
		
		return banderas;
	}
	
	/**
	 * Método que cuenta las celdas que tienen de estado descubiertas.
	 * 
	 * @return descubiertas
	 */
	public int contarCeldasDescubiertas() {
		
		int descubiertas = 0;
		
		while(celda.estaDescubierta()) {
			descubiertas++;
		}
		
		return descubiertas;
	}
	
	public int contarMinas() {
		return 0;
	}
	
	/**
	 * Método que devuelve el número de celdas descubiertas que contienen minas.
	 * 
	 * @return contador
	 */
	public int contarMinasExplotadas() {
		
		int contador = 0;
		while (celda.estaDescubierta() && celda.tieneMina()) {
			contador++;
		}
		return contador;
	}
	
	public void descubrir(int fila, int columna) {
		if(celda.obtenerNumeroMinasAdyacentes() == 0 && fila < NUMERO_FILAS && columna < NUMERO_COLUMNAS) {
			celda.establecerSiguienteEstadoDescubrir();
		}
	}
	
	/**
	 * Método que cambia el estado de la celda de marcada a desmarcada o viceversa.
	 * 
	 * @param fila
	 * @param columna
	 */
	public void marcarDesmarcar(int fila, int columna) {
		if(celda.estaOculta()) {
			estado = Estado.MARCADA;
		}else if(celda.estaMarcada()) {
			estado = Estado.OCULTA;
		}
	}
	
	/**
	 * Método que devuelve la referencia a la celda del tablero.
	 * 
	 * @param fila
	 * @param columna
	 * @return celdas[filas][columna]
	 */
	Celda obtenerCelda(int fila, int columna) {
		return celdas[fila][columna];
	}
	
	/**
	 * Método que obtiene el número de columnas.
	 * 
	 * @return celdas[0].length
	 */
	public int obtenerNumeroColumnas() {
		return celdas[0].length;
	}

	/**
	 * Método que obtiene el número de filas.
	 * 
	 * @return celdas.length
	 */
	public int obtenerNumeroFilas() {
		return celdas.length;
	}
	
	public String obtenerSolucion() {
		return "";
	}
	
	public String toString() {
		return "";
	}
}
