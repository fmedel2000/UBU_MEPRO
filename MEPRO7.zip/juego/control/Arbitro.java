package juego.control;
import juego.modelo.*;
/**
 * 
 * @author Francisco Medel, Alex Tom�
 * @version 1.0
 */
public class Arbitro {
	
	public Arbitro(){
		
	}
	
	public Tablero consultarTablero() {
		return null;
	}
	
	void descubrir(int fila, int columna) {
		
	}
	
	void descubrirOcultas() {
		
	}
	
	public boolean esLegalDescubrir(int fila, int columna) {
		return false;
	}
	
	public boolean esLegalDesmarcar(int fila, int columna) {
		return false;
	}
	
	public boolean esLegalMarcar(int fila, int columna) {
		return false;
	}
	public boolean haExplotadoAlgunaMina() {
		return false;
	}
	public boolean haFinalizadoConExito() {
		return false;
	}
	void marcarODesmarcar(int fila, int columna) {
		
	}
}
