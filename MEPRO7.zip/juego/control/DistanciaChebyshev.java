package juego.control;
import juego.modelo.Celda;

/**
 * Clase para calcular las distancias entre celdas.
 * 
 * @author Francisco Medel, Alex Tomé
 * @version 1.0
 */
public class DistanciaChebyshev{
	
	/**
	 * Método que calcula la distancia entre dos celdas.
	 * 
	 * @param origen
	 * @param elegida
	 * @return distancia
	 */
	public int calcular(Celda origen, Celda elegida) {
		
		int distancia = 0;
		distancia = Math.max(Math.abs(elegida.obtenerFila()-origen.obtenerFila()), Math.abs(elegida.obtenerColumna()-origen.obtenerColumna()));
		return distancia;
	}
}