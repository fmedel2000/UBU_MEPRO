package juego.modelo;
/**
 * 
 * @author Francisco Medel, Alex Tom�
 * @version 1.0
 */
public class Celda {
	private int fila;
	private int columna;
	
	public Celda(int fila, int columna) {
		
	}
	
	public Celda clonar() {
		return null;
	}
	
	void colocarMina() {
		
	}
	
	void establecerNumeroMinasAdyacentes(int numeroMinas) {
		
	}
	
	void establecerSiguienteEstadoDescubrir() {
		
	}
	
	void establecerSiguienteEstadoMarcar() {
		
	}
	
	public boolean estaDescubierta() {
		return false;
	}
	
	public boolean estaMarcada() {
		return false;
	}
	
	public boolean estaOculta() {
		return false;
	}
	
	public int obtenerColumna() {
		return 0;
	}
	public int obtenerFila() {
		return 0;
	}
	
	public int obtenerNumeroMinasAdyacentes() {
		return 0;
	}
	
	public String obtenerTextoEstado() {
		return null;
	}
	
	public String obtenerTextoSolucion() {
		return null;
	}
	
	public boolean tieneCoordenadasIguales(Celda celda) {
		return false;
	}
	
	public boolean tieneMina() {
		return false;
	}
	
	public String toString() {
		return null;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + columna;
		result = prime * result + fila;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Celda other = (Celda) obj;
		if (columna != other.columna)
			return false;
		if (fila != other.fila)
			return false;
		return true;
	}
	
}
