package juego.modelo;
/**
 * 
 * @author Francisco Medel, Alex Tom�
 * @version 1.0
 */
public class Tablero {
	private int fila;
	private int columna;
	public Tablero(){
		
	}
	public Tablero clonar() {
		return null;
	}
	
	public Celda clonarCelda(int fila, int columna) {
		return null;
	}
	
}
