package juego.modelo;
/**
 * 
 * @author Francisco Medel, Alex Tom�
 * @version 1.0
 */
public enum Estado {
	MARCADA('P'), DESCUBIERTA('O'), OCULTA('-');
	
	private char letra;
	
	private Estado(char letra) {
		this.letra = letra;
	}
	
	public char obtenerLetra() {
		return letra;
	}
}
