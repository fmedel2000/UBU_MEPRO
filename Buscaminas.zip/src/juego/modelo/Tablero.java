package juego.modelo;
import java.util.Random;
import juego.control.DistanciaChebyshev;
import juego.modelo.Celda;
import juego.util.Sentido;

/**
 * Clase del tablero del juego. Instancia las celdas en un tablero 8*8 y coloca las minas.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.4
 */
public class Tablero {
	
	/**
	 * NUMERO_FILAS.
	 */
	public static final int NUMERO_FILAS = 8;
	
	/**
	 * NUMERO_COLUMNAS.
	 */
	public static final int NUMERO_COLUMNAS = 8;
	
	/**
	 * Celdas.
	 */
	private Celda[][] celdas;
	
	/**
	 * Método constructor del tablero.
	 */
	public Tablero(){
		
		celdas = new Celda[NUMERO_FILAS][NUMERO_COLUMNAS];
		
		for(int fila=0; fila < NUMERO_FILAS; fila++) {
			for(int columna=0; columna < NUMERO_COLUMNAS; columna++) {
				celdas[fila][columna] =  new Celda(fila, columna);
			}
		}
		
	}
	
	/**
	 * Método que hace un clon del tablero.
	 * 
	 * @return clon del tablero
	 */
	public Tablero clonar() {
		Tablero clon = new Tablero();
		
		for(int fila=0; fila < NUMERO_FILAS; fila++) {
			for(int columna=0; columna < NUMERO_COLUMNAS; columna++) {
				clon.celdas[fila][columna] =  this.celdas[fila][columna].clonar();
			}
		}
		
		return clon;
	}
	
	/**
	 * Método que clona una celda en las coordenadas correspondientes.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @return clon o null si sobrepasa los límites del tablero la coordenada correspondiente
	 */
	public Celda clonarCelda(int fila, int columna) {
		//Comprobamos que está dentro de los límites del tablero.
		if((columna >= NUMERO_COLUMNAS || columna < 0) || (fila >= NUMERO_FILAS || fila < 0)) {
			return null;
		}else {
			Celda clon = celdas[fila][columna].clonar();
			return clon;
		}
		
	}
	
	/**
	 * Método que clona las celdas a un array.
	 * 
	 * @return listaclon
	 */
	public Celda[] clonarCeldas() {
		//Hacemos un array de celdas y las almacenamos.
		Celda[] clon;
		clon = new Celda[NUMERO_FILAS * NUMERO_COLUMNAS];
		
		for(int fila=0; fila < NUMERO_FILAS; fila++) {
			for(int columna=0; columna < NUMERO_COLUMNAS; columna++) {
				clon[8*fila+columna] = celdas[fila][columna].clonar();
			}
		}
		return clon;
	}
	
	/**
	 * Método que coloca las minas en el tablero.
	 * 
	 * @param inicio celda de origen
	 * @param distancia distancia de chebyshev
	 * @param rd numero aleatorio
	 */
	public void colocarMinas(Celda inicio, DistanciaChebyshev distancia, Random rd) {
		//Creamos un bucle con límite 10 para que se coloquen las 10 minas.
		for(int i = 0; i < 10; i++) {
			
			//Generamos las coordenadas aleatorias.
			int fila = rd.nextInt(8);
		    int columna =rd.nextInt(8);
		    
		    //Comprobamos que se puede colocar la mina si la celda origen no es la de destino, no tiene mina y la distancia de chebyshev es mayor a 1.
		    if (celdas[fila][columna] != inicio && !celdas[fila][columna].tieneMina() && distancia.calcular(inicio,celdas[fila][columna]) > 1) {
		    	celdas[fila][columna].colocarMina();
		    	//Recorremos en todos los sentidos.
		    	for(Sentido p : Sentido.values()) {
		    		//Creamos dos enteros con la fila y columna de la celda y sus respectivos desplazamientos del sentido.
                    int x = celdas[fila][columna].obtenerFila() + p.obtenerDesplazamientoEnFilas();
                    int y = celdas[fila][columna].obtenerColumna() + p.obtenerDesplazamientoEnColumnas();
                    
                    //Para establecer las minas adyacentes, comprobamos que está en los límites, que está oculta y no tiene mina.
                    //Si es así, establecemos el número de minas adyacentes.
                    if ( ((0 <= x && x <= 7) && (0 <= y && y <= 7)) && celdas[x][y].estaOculta() && !celdas[x][y].tieneMina()) {
                        int numeroMinasAdyacentes = celdas[x][y].obtenerNumeroMinasAdyacentes();
                        celdas[x][y].establecerNumeroMinasAdyacentes(numeroMinasAdyacentes+1);
                    }
                }
		    }else {
		    	//Si no se coloca una mina, volvemos atrás en el bucle para reintentar y colocar las 10 minas.
		    	i--;
		    }
		}

    }
	
	/**
	 * Método que cuenta las celdas marcadas (banderas).
	 * 
	 * @return banderas
	 */
	public int contarBanderas() {
		
		int banderas = 0;
		for (int i= 0; i < NUMERO_FILAS ; i++) {
            for (int j= 0; j < NUMERO_COLUMNAS ; j++) {
            	//Si la celda está marcada, aumentamos el contador de banderas.
            	if(celdas[i][j].estaMarcada()) {
    				banderas++;
            	}			
			}
		}
		return banderas;
	}
	
	/**
	 * Método que cuenta las celdas que tienen de estado descubiertas.
	 * 
	 * @return descubiertas
	 */
	public int contarCeldasDescubiertas() {
		
		int descubiertas = 0;	
		for (int i= 0; i < NUMERO_FILAS ; i++) {
            for (int j= 0; j < NUMERO_COLUMNAS ; j++) {
            	//Si la celda está descubierta, aumentamos el contador de descubiertas.
            	if(celdas[i][j].estaDescubierta()) {
            		descubiertas++;
            	}	
			}
		}	
		return descubiertas;
	}
	
	/**
	 * Método que cuenta las minas.
	 * 
	 * @return contador
	 */
	public int contarMinas() {
		int contador = 0;
		
		for (int i= 0; i < NUMERO_FILAS ; i++) {
            for (int j= 0; j < NUMERO_COLUMNAS ; j++) {
            	//Si la celda tiene mina, aumentamos el contador de minas.
                if(celdas[i][j].tieneMina()) {
                	contador++;
                }
            }
        }
		return contador;
	}
	
	/**
	 * Método que devuelve el número de celdas descubiertas que contienen minas.
	 * 
	 * @return contador
	 */
	public int contarMinasExplotadas() {
		
		int contador = 0;
		
		for (int i= 0; i < NUMERO_FILAS ; i++) {
            for (int j= 0; j < NUMERO_COLUMNAS ; j++) {
            	//Si la celda tiene mina y además está descubierta, aumentamos el contador.
                if(celdas[i][j].tieneMina() && celdas[i][j].estaDescubierta()) {
                	contador++;
                }
            }
        }
		return contador;
	}
	
	/**
	 * Método que descubre las celdas.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 */
	public void descubrir(int fila, int columna) {
		//Comprobamos si está dentro de los límites del tablero y descubrimos.
		if( (fila < 8 && fila >= 0) && (columna < 8 && columna >= 0) ) {
			celdas[fila][columna].establecerSiguienteEstadoDescubrir();
		}
			
	    if(celdas[fila][columna].obtenerNumeroMinasAdyacentes() == 0){
	    	//Recorremos en todos los sentidos.
	        for(Sentido s : Sentido.values()) {
	        	//Creamos dos enteros para las filas y las columnas desplazadas a partir de la celda y el desplazamiento del sentido.
	        	int filaDesp = celdas[fila][columna].obtenerFila() + s.obtenerDesplazamientoEnFilas();
			    int columnaDesp = celdas[fila][columna].obtenerColumna() + s.obtenerDesplazamientoEnColumnas();
			     
			    //Si las minas adyacentes son igual a cero, hacemos recursividad. Si no, directamente establecemos el siguiente estado.
			    //Para ello también se comprueba que la celda está oculta y no tiene mina.
			    if ( ((filaDesp < 8 && filaDesp >= 0) && (columnaDesp < 8 && columnaDesp >= 0)) && celdas[filaDesp][columnaDesp].estaOculta() && (!celdas[filaDesp][columnaDesp].tieneMina() ) && (celdas[filaDesp][columnaDesp].obtenerNumeroMinasAdyacentes() > 0) ) {
			    	celdas[filaDesp][columnaDesp].establecerSiguienteEstadoDescubrir();
			    }
			    if ( ((filaDesp < 8 && filaDesp >= 0) && (columnaDesp < 8 && columnaDesp >= 0)) && celdas[filaDesp][columnaDesp].estaOculta() && (!celdas[filaDesp][columnaDesp].tieneMina() ) && (celdas[filaDesp][columnaDesp].obtenerNumeroMinasAdyacentes() == 0) ) {
			        celdas[filaDesp][columnaDesp].establecerSiguienteEstadoDescubrir();
			        	descubrir(filaDesp,columnaDesp);
			    }
	        }
	    }
        
	}
	
	/**
	 * Método que cambia el estado de la celda de marcada a desmarcada o viceversa.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 */
	public void marcarDesmarcar(int fila, int columna) {
		celdas[fila][columna].establecerSiguienteEstadoMarcar();
	}
	
	/**
	 * Método que devuelve la referencia a la celda del tablero.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @return celdas[filas][columna]
	 */
	Celda obtenerCelda(int fila, int columna) {
		//Comprobamos que está dentro de los límites y si es así, devolvemos la celda.
		if(fila >= NUMERO_FILAS || columna >= NUMERO_COLUMNAS || fila < 0 || columna < 0) {
			return null;
		}else {
			return celdas[fila][columna];
		}	
		
	}
	
	/**
	 * Método que obtiene el número de columnas.
	 * 
	 * @return NUMERO_COLUMNAS
	 */
	public int obtenerNumeroColumnas() {
		return NUMERO_COLUMNAS;
	}

	/**
	 * Método que obtiene el número de filas.
	 * 
	 * @return NUMERO_FILAS
	 */
	public int obtenerNumeroFilas() {
		return NUMERO_FILAS;
	}
	
	/**
	 * Método que obtiene la solución del tablero en cadena de texto.
	 * 
	 * @return t Tablero en cadena de texto
	 */
	public String obtenerSolucion() {
		//Hacemos un doble bucle para hacer print de todo el tablero.
		String t="";
		for(int i=0;i<=7;i++) {
			t=t+(i);
			for (int j=0;j<=7;j++){
				//Obtenemos el texto de la solución de las celdas.
				t=t+celdas[i][j].obtenerTextoSolucion();
			}
			t=t+"\n";
		}
		t=t+"  0  1  2  3  4  5  6  7";
		return t;
	}
	
	/**
	 * Método que obtiene el tablero en cadena de texto.
	 * 
	 * @return t Tablero en cadena de texto
	 */
	public String toString() {
		//Hacemos un doble bucle para hacer print de todo el tablero.
		String t="";
		for(int i=0;i<=7;i++) {
			t=t+(i);
			for (int j=0;j<=7;j++){
				//Obtenemos el texto del estado de las celdas.
				t=t+celdas[i][j].obtenerTextoEstado();
			}
			t=t+"\n";
		}
		t=t+"  0  1  2  3  4  5  6  7";
			return t;
	}
}
