package juego.control;
import juego.modelo.*;
import java.util.Random;

/**
 * Clase del árbitro del buscaminas. Controla al tablero y comprueba las legalidades de movimiento.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.4
 */
public class Arbitro {
	
	/**
	 * maxBanderas.
	 */
	private int maxBanderas = 10;
	
	/**
	 * Celdas.
	 */
	private Celda[][] celdas;
	
	/**
	 * Tablero.
	 */
	private Tablero tablero;
	
	/**
	 * Método constructor del árbitro.
	 */
	public Arbitro(){
		tablero = new Tablero();
		//Construimos las celdas también.
		celdas = new Celda[tablero.obtenerNumeroFilas()][tablero.obtenerNumeroColumnas()];
	
	}
	
	/**
	 * Método que consulta y crea un clon del tablero.
	 * 
	 * @return clonTablero
	 */
	public Tablero consultarTablero() {
		//Hacemos un clon del tablero.
		Tablero clonTablero = new Tablero();
		clonTablero = tablero.clonar();
	    return clonTablero;
	}
	
	/**
	 * Método que descubre las celdas al colocarlas tras primer movimiento.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 */
	public void descubrir(int fila, int columna) {
		
		//Se hace un if que comprueba si es primer movimiento.
		//Si el número de minas es distinto de 10, quiere decir que no están colocadas y por tanto es primer movimiento.
        if(tablero.contarMinas() != 10) {
            celdas[fila][columna] = tablero.clonarCelda(fila,columna);
            //Colocamos las minas.
            tablero.colocarMinas(celdas[fila][columna], new DistanciaChebyshev(), new Random((fila*10L + columna)));
        }
        //Descubrimos.
        tablero.descubrir(fila, columna);
       
	}
	
	/**
	 * Método que descubre todas las celdas ocultas.
	 */
	public void descubrirOcultas() {
		 for (int i= 0; i < tablero.obtenerNumeroFilas() ; i++) {
	            for (int j= 0; j < tablero.obtenerNumeroColumnas() ; j++) {
	            	celdas[i][j] = tablero.clonarCelda(i,j);
	            	//Si la celda está oculta, descubrimos.
	            	if(celdas[i][j].estaOculta()) {
	            		descubrir(i, j);
	            	}
	            }
	        }
	}
	
	/**
	 * Método que comprueba si es legal descubrir una celda.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @return true si se puede descubrir o false si no se puede
	 */
	public boolean esLegalDescubrir(int fila, int columna) {
        //Recorremos el bucle y clonamos las celdas.
        for (int i= 0; i < tablero.obtenerNumeroFilas() ; i++) {
            for (int j= 0; j < tablero.obtenerNumeroColumnas() ; j++) {
                celdas[i][j] = tablero.clonarCelda(i, j);
            }
        }
        
        //Si la celda está en los límites del tablero, está oculta y no está marcada, se puede descubrir.
        if ((0 <= fila && fila <= 7) && (0 <= columna && columna <= 7) && celdas[fila][columna].estaOculta() && !celdas[fila][columna].estaMarcada() ) {
            return true;
        }else {
            return false;
        }
	}
	
	/**
	 * Método que comprueba si es legal desmarcar la celda.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @return true si se puede desmarcar o false si no se puede
	 */
	public boolean esLegalDesmarcar(int fila, int columna) {
		
		//Clonamos las celdas.
        celdas[fila][columna] = tablero.clonarCelda(fila, columna);

        //Si está dentro de los límites y la celda está marcada y no descubierta, se puede desmarcar.
		if((0 <= fila && fila <= 7) && (0 <= columna && columna <= 7) && celdas[fila][columna].estaMarcada() && !celdas[fila][columna].estaDescubierta()) {
			return true;
		}else {
			return false;
		}
		
	}
	
	/**
	 * Método que comprueba la legalidad para marcar una celda.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 * @return true si se puede marcar o false si no se puede
	 */
	public boolean esLegalMarcar(int fila, int columna) {
		
        //Clonamos la celda.
        for (int i= 0; i < tablero.obtenerNumeroFilas() ; i++) {
            for (int j= 0; j < tablero.obtenerNumeroColumnas() ; j++) {
                celdas[i][j] = tablero.clonarCelda(i, j);
            }
        }
        
        //Si está dentro de los límites del tablero, el número de banderas menor al máximo(10) y las celdas no están ni marcadas ni descubiertas, se pueden marcar.
		if((0 <= fila && fila <= 7) && (0 <= columna && columna <= 7) && tablero.contarBanderas() < maxBanderas && !celdas[fila][columna].estaMarcada() && !celdas[fila][columna].estaDescubierta()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Método que comprueba si ha explotado alguna mina.
	 * 
	 * @return true si ha explotado alguna mina o false si no
	 */
	public boolean haExplotadoAlgunaMina() {
		//Si las minas explotadas son distintas a cero, es porque ha explotado alguna mina.
		if(tablero.contarMinasExplotadas() != 0) {
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Método que comprueba si el juego ha finalizado con éxito.
	 * 
	 * @return true si ha finalizado con éxito o false si no
	 */
	public boolean haFinalizadoConExito() {
		//Creamos un contador de celdas sin minas.
        int contador=0;
        //Son las 64 celdas del tablero - las 10 minas colocadas.
        int celdasDescubiertasConExito = tablero.obtenerNumeroFilas()*tablero.obtenerNumeroColumnas() - tablero.contarMinas(); 
        
        //Recorremos el tablero.
        for (int i= 0; i < tablero.obtenerNumeroFilas() ; i++) {
    		for (int j= 0; j < tablero.obtenerNumeroColumnas() ; j++) {
    			//Clonamos las celdas.
    			celdas[i][j] = tablero.clonarCelda(i, j);
    			
    			//Si la celda está descubierta y no tiene mina, aumentamos el contador.
    			if(celdas[i][j].estaDescubierta() && !celdas[i][j].tieneMina()) {
    				contador++;
    			}
    		}
    	}      
        
        //Si el contador es 54 (64 celdas - 10 minas), no ha explotado ninguna mina y además están las 10 minas colocadas, ha ganado.
        if(contador == celdasDescubiertasConExito && !haExplotadoAlgunaMina() && tablero.contarMinas() == 10) {
        	return true;
        }else {
        	return false;
        }
    
	}
	
	/**
	 * Método que marca o desmarca las celdas, dependiendo de su estado.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 */
	public void marcarODesmarcar(int fila, int columna) {
        //Comprueba la legalidad de marcar o desmarcar y cambia el estado en el tablero.
        if((esLegalMarcar(fila,columna) || esLegalDesmarcar(fila,columna))) {
        	tablero.marcarDesmarcar(fila, columna);
        }
	}
}