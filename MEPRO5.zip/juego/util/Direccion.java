package juego.util;
/**
 * @author Francisco Medel Molinero
 *  Direccion
 * */
public enum Direccion {
	HORIZONTAL,
	VERTICAL,
	DIAGONAL_SO_NE,
	DIAGONAL_NO_SE;
}
