package juego.modelo;
import juego.util.Direccion;

/**
 * @author Francisco Medel Molinero
 *  Tablero
 * */

public class Tablero {
	//queremos crear un tablero en el que va a haber celdas
	private Celda [] [] celdas;
	
	public Tablero(int filas, int columnas) {
	
		celdas = new Celda[filas][columnas];
	
		for(int fila=0; fila < filas;fila++) {
			
			for(int columna=0;columna<columnas;columna++) {
			celdas[fila][columna] = new Celda(fila,columna);
			}
	}
	}
	
	
	/**
	 * procedimiento que coloca la pieza en una celda
	 * @param pieza	
	 * @param celda
	 */
	public void colocar(Pieza pieza,Celda celda) {
		pieza.establecerCelda(celda);
		celda.establecerPieza(pieza);
	}
	/**
	 * 
	 * @return numero de filas
	 */
	public int obtenerNumeroFilas() {
		return celdas.length;
	}
	/**
	 * 
	 * @return numero de columnas
	 */
	public int obtenerNumeroColumnas() {
		return celdas[0].length;
	}
	/**
	 * 
	 * @param fila 
	 * @param columna
	 * @return celda
	 */
	public Celda obtenerCelda(int fila, int columna) {
		return celdas[fila][columna];
	}
	/**
	 * 
	 * @return contador (numero de piezas)
	 */
	public int obtenerNumeroPiezas() {
		int contador=0;
		for(int i = 0; i < obtenerNumeroFilas();i++) {
			for(int j=0; j<obtenerNumeroColumnas();j++) {
				Celda celda=obtenerCelda(i,j);
				if(!celda.estaVacia()) {
					contador++;
				}
			}
		}
		return contador;
	}
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Tablero tablero = new Tablero(3,3);
		
		Celda celda00 = tablero.obtenerCelda(0, 0);
		Celda celda11 = tablero.obtenerCelda(1, 1);
		Celda celda22 = tablero.obtenerCelda(2, 2);
		
		Pieza pieza1 = new Pieza(Color.NEGRO);
		Pieza pieza2 = new Pieza(Color.NEGRO);
		Pieza pieza3 = new Pieza(Color.NEGRO);
		
		tablero.colocar(pieza1, celda00);
		tablero.colocar(pieza2, celda11);
		tablero.colocar(pieza3, celda22);		
	}
	
	/**
	 * Comprueba si esta en el tablero
	 * @param i
	 * @param j
	 * @return
	 */
	public boolean estaEnTablero(int i, int j) {
		return false;
	}
	 
	public boolean estaCompleto() {
		return false;
	}
	
	public int contarPiezas(Celda celda,Direccion direccion) {
		int contador = 0;
		int desplFila = 0;
		int desplColumna = 0;
		switch(direccion) {
		case HORIZONTAL:
			desplFila = 0;
			desplColumna = 1;
			break;
		case VERTICAL:
			desplFila = 1;
			desplColumna = 0;
			break;
		case DIAGONAL_NO_SE:
			desplFila = -1;
			desplColumna = -1;
			break;
		case DIAGONAL_SO_NE:
			desplFila = -1;
			desplColumna = +1;
			break;
		}
		contador += contar(celda, desplFila, desplColumna);
		contador += contar(celda, desplFila * -1, desplColumna * -1);
		return contador;
	}
	
	private int contar(Celda origen, int desplFila, int desplColumna) {
		if (origen.estaVacia()) return 0;
		Color colorABuscar = origen.obtenerPieza().obtenerColor();
		int contador = 1;
		int x = origen.obtenerFila();
		int y = origen.obtenerColumna();
		boolean continuar = true;
		do {
			x+= despFila;
			y+= despColumna;
			if(estaEnTablero(x,y)) {
				Celda celda = this.obtenerCelda(x, y);
				if(!celda.estaVacia() && celda.obtenerPieza().obtenerColor() == colorABuscar) {
					contador++;
				}
				else {
					continuar = false;
				}
			}
			else {
				continuar = false;
			}
		}while(continuar);
	return 0;
	}
}
