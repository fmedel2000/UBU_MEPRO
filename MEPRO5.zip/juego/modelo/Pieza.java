package juego.modelo;
/**
 * @author Francisco Medel Molinero
 *  Pieza
 * */
public class Pieza {
	
	private Color color;
	private Celda celda;
	
	public Pieza(Color color) {
		//this.color=color;
		establecerColor(color);
	}
	/**
	 * establece el color
	 * @param color
	 */
	private void establecerColor(Color color) {
		this.color = color;
	}
	
	/**
	 * establece la celda
	 * @param celda
	 */
	public void establecerCelda(Celda celda) {
		this.celda = celda;
	}
	/**
	 * obtiene la celda
	 * @return
	 */
	public Celda obtenerCelda() {
		return celda;
	}
	/**
	 * obtiene el color
	 * @return
	 */
	public Color obtenerColor() {
		return color;
	}
	public String toString() {
		return celda + "-" + color;
	}
}
