package juego.modelo;
/**
 * @author Francisco Medel Molinero
 *  Jugador
 * */
public class Jugador {
	private String nombre;
	private Color color;
	public Jugador(String nombre,Color color) {
		//Para que no se llene de null el nombre y el color
		this.nombre = nombre;
		this.color = color;		
	}
	//Es una funcion y no un procedimiento porque sirve para consultar
	public String obtenerNombre() {
		return nombre;
	}
	//Es una funcion y no un procedimiento porque sirve para consultar
	public Color obtenerColor() {
		return color;
	}
	public Pieza generarPieza() {
		return new Pieza(this.color);
	}
	public String toString() {
		return nombre + "-" + color;
	}
	
}
