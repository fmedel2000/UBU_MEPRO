package juego.modelo;
/**
 * @author Francisco Medel Molinero
 *  Color
 * */

public enum Color {
	
	BLANCO('O'),
	NEGRO('X');
	
	private char car�cter;
	
	private Color(char letra) {
		this.car�cter=letra;
	}
	
	public char toChar() {
		return car�cter;
	}
	
}
