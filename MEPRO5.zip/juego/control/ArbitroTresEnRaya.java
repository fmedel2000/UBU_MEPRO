package juego.control;
import juego.modelo.Jugador;
import juego.modelo.Tablero;
/**
 * @author Francisco Medel Molinero
 *  Arbitro
 * */
public class ArbitroTresEnRaya {
	public ArbitroTresEnRaya() {
		
	}
	public void registrarJugador(String nombre) {
		
	}
	
	public Jugador obtenerTurno() {
		return null;
	}
	
	public Tablero obtenerTablero() {
		return null;
	}
	
	public boolean esMovimientoLegal(int i, int j) {
		return false;
	}
	
	public void jugar(int i, int j) {
		
	}
	
	public Jugador obtenerGanador() {
		return null;
	}
	
	public boolean estaAcabado() {
		return false;
	}
}
