package juego.control;

import juego.modelo.Celda;
import juego.modelo.Tablero;
import juego.util.CoordenadasIncorrectasException;

/**
 * Clase abstracta padre del árbitro. Se divide en seguro e inseguro.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.3
 */
public abstract class ArbitroAbstracto implements Arbitro{
	
	/**
	 * maxBanderas.
	 */
	private int maxBanderas = 10;
	
	/**
	 * Celda.
	 */	
	private Celda celda;
	
	/**
	 * Tablero.
	 */
	private Tablero tablero;
	
	/**
	 * Método constructor del árbitro abstracto.
	 * 
	 * Coge el tablero del juego.
	 * 
	 * @param tablero tablero del juego
	 */
	public ArbitroAbstracto(Tablero tablero) {
		this.tablero = tablero;
	}
	
	/**
	 * Comprueba si la partida está finalizada.
	 * 
	 * Una partida está finalizada si todas las celdas descubiertas no son minas y
	 * se han colocado la minas.
	 * 
	 * @return true si está acabada, false en caso contrario
	 */
	@Override
	public boolean haFinalizadoConExito() {
		//Creamos un contador de celdas sin minas.
        int contador=0;
        //Son las 64 celdas del tablero - las 10 minas colocadas.
        int celdasDescubiertasConExito = tablero.obtenerNumeroFilas()*tablero.obtenerNumeroColumnas() - tablero.contarMinas(); 
        
        //Recorremos el tablero.
        for (int i= 0; i < tablero.obtenerNumeroFilas() ; i++) {
    		for (int j= 0; j < tablero.obtenerNumeroColumnas() ; j++) {
    			//Clonamos las celdas.
    			try {
					celda = tablero.clonarCelda(i, j);
				} catch (CoordenadasIncorrectasException e) {
					// TODO Auto-generated catch block
					
				}
    			//Si la celda está descubierta y no tiene mina, aumentamos el contador.
    			if(celda.estaDescubierta() && !celda.tieneMina()) {
    				contador++;
    			}
    		}
    	}      
        
        //Si el contador es 54 (64 celdas - 10 minas), no ha explotado ninguna mina y además están las 10 minas colocadas, ha ganado.
        if(contador == celdasDescubiertasConExito && !haExplotadoAlgunaMina() && tablero.contarMinas() == 10) {
        	return true;
        }else {
        	return false;
        }
	}

	/**
	 * Comprueba si ha explotado alguna mina.
	 * 
	 * @return true si ha explotado alguna mina, false en caso contrario
	 */
	@Override
	public boolean haExplotadoAlgunaMina() {
		//Si las minas explotadas son distintas a cero, es porque ha explotado alguna mina.
		if(tablero.contarMinasExplotadas() != 0) {
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Descubre todas las celdas ocultas actualmente.
	 */
	@Override
	public void descubrirOcultas() {
		for (int i= 0; i < tablero.obtenerNumeroFilas() ; i++) {
			 for (int j= 0; j < tablero.obtenerNumeroColumnas() ; j++) {
	            try {
					celda = tablero.clonarCelda(i,j);
				} catch (CoordenadasIncorrectasException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            //Si la celda está oculta, descubrimos.
	            if(celda.estaOculta()) {
	            	try {
						tablero.descubrir(i, j);
					} catch (CoordenadasIncorrectasException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
	         }
	     }
	}

	/**
	 * Marca o desmarca la celda si es posible.
	 * 
	 * @param fila fila
	 * @param columna columna
	 * @throws CoordenadasIncorrectasException si las coordenadas están fuera del tablero
	 */
	@Override
	public void marcarODesmarcar(int fila, int columna) throws CoordenadasIncorrectasException {
		try {
			if((columna >= 8 || columna < 0) || (fila >= 8 || fila < 0)) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else{
				if((esLegalMarcar(fila,columna) || esLegalDesmarcar(fila,columna))) {
					tablero.marcarDesmarcar(fila, columna);
				}
			}
		}catch(CoordenadasIncorrectasException e) {
			throw new CoordenadasIncorrectasException("No se puede marcar la celda",e);
		}
	}

	/**
	 * Comprueba si es legal descubrir la celda.
	 * 
	 * @param fila fila
	 * @param columna columna
	 * @return true si es legal descubrir, false en caso contrario
	 * @throws CoordenadasIncorrectasException si las coordenadas están fuera del tablero
	 */
	@Override
	public boolean esLegalDescubrir(int fila, int columna) throws CoordenadasIncorrectasException{
        
        //Si la celda está en los límites del tablero, está oculta y no está marcada, se puede descubrir.
        try {
			if((columna >= 8 || columna < 0) || (fila >= 8 || fila < 0)) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else{
				celda = tablero.clonarCelda(fila, columna);
				if (celda.estaOculta()) {
					return true;
				}else {
					return false;
				}
			}
        }catch(CoordenadasIncorrectasException e) {
			throw new CoordenadasIncorrectasException("No se puede descubrir la celda",e);
        }
	}

	/**
	 * Comprueba si es legal marcar la celda.
	 * 
	 * @param fila fila
	 * @param columna columna
	 * @return true si es legal marcar, false en caso contrario
	 * @throws CoordenadasIncorrectasException si las coordenadas están fuera del tablero
	 */
	@Override
	public boolean esLegalMarcar(int fila, int columna) throws CoordenadasIncorrectasException{
		
        //Si está dentro de los límites del tablero, el número de banderas menor al máximo(10) y las celdas no están ni marcadas ni descubiertas, se pueden marcar.
		try {
			if((columna >= 8 || columna < 0) || (fila >= 8 || fila < 0)) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else{
				if(tablero.contarBanderas() < maxBanderas && esLegalDescubrir(fila,columna)) {
					return true;
				}else {
					return false;
				}
			}
		}catch(CoordenadasIncorrectasException e) {
			throw new CoordenadasIncorrectasException("No se puede marcar la celda",e);
		}
	}

	/**
	 * Comprueba si es legal desmarcar la celda.
	 * 
	 * @param fila fila
	 * @param columna columna
	 * @return true si es legal desmarcar, false en caso contrario
	 * @throws CoordenadasIncorrectasException si las coordenadas están fuera del tablero
	 */
	@Override
	public boolean esLegalDesmarcar(int fila, int columna) throws CoordenadasIncorrectasException{
		
		celda = tablero.clonarCelda(fila, columna);
		
        //Si está dentro de los límites del tablero, el número de banderas menor al máximo(10) y las celdas no están ni marcadas ni descubiertas, se pueden marcar.
		try {
			if((columna >= 8 || columna < 0) || (fila >= 8 || fila < 0)) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else{
				//Si está dentro de los límites y la celda está marcada y no descubierta, se puede desmarcar.
				if(celda.estaMarcada() && !celda.estaDescubierta()) {
					return true;
				}else {
					return false;
				}
			}
		}catch(CoordenadasIncorrectasException e) {
			throw new CoordenadasIncorrectasException("No se puede marcar la celda",e);
		}
	}

	/**
	 * Clona un tablero.
	 * 
	 * @return clon del tablero actual solo para consulta
	 */
	@Override
	public Tablero consultarTablero() {
		//Hacemos un clon del tablero.
		Tablero clonTablero = new Tablero();
		clonTablero = tablero.clonar();
	    return clonTablero;
	}
}