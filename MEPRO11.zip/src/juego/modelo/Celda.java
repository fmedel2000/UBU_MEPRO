package juego.modelo;

/**
 * Clase de las celdas del juego.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.3
 */
public class Celda {
	
	/**
	 * TEXTO_MINA.
	 */
	protected static String TEXTO_MINA = " M ";
	
	/**
	 * numeroMinasAdy.
	 */
	private int numeroMinasAdy = 0;
	
	/**
	 * Estado.
	 */
	private Estado estado = Estado.OCULTA;;
	
	/**
	 * Celda.
	 */
	private Celda celda;
	
	/**
	 * Fila.
	 */
	private int fila;
	
	/**
	 * Columna.
	 */
	private int columna;
	
	/**
	 * Método constructor de la celda.
	 * 
	 * @param fila filas
	 * @param columna columnas
	 */
	public Celda(int fila, int columna) {
		this.fila = fila;
		this.columna = columna;
		
	}
	
	/**
	 * Método que clona una celda independiente.
	 * 
	 * @return clon
	 */
	public Celda clonar() {
		//Hacemos un clon idéntico a la celda.
		Celda clon = new Celda(obtenerFila(), obtenerColumna());
		clon.estado = obtenerEstado();
		clon.numeroMinasAdy = obtenerNumeroMinasAdyacentes();
		return clon;
	}
	
	/**
	 * Método que coloca la mina.
	 */
	void colocarMina() {
		numeroMinasAdy = -1;
	}
	
	/**
	 * Método que establece el número de minas adyacentes.
	 * 
	 * @param numeroMinas numero de minas
	 */
	void establecerNumeroMinasAdyacentes(int numeroMinas) {
		numeroMinasAdy = numeroMinas;
	}
	
	/**
	 * Método que cambia el estado de la celda al descubrirla.
	 */
	void establecerSiguienteEstadoDescubrir() {
		//Si la celda está oculta, su estado cambia a descubrir.
		if(estaOculta()) {
			estado = Estado.DESCUBIERTA;
		}
	}
	
	/**
	 * Método que cambia el estado de la celda al marcarla.
	 */
	void establecerSiguienteEstadoMarcar() {
		//Si está oculta, se marca la celda y si está marcada, la ocultamos.
		if(estaOculta()) {
			estado = Estado.MARCADA;
		}else if(estaMarcada()) {
			estado = Estado.OCULTA;
		}
	}
	
	/**
	 * Método que comprueba que el estado de la celda es descubierta.
	 * 
	 * @return true si lo está o false si no
	 */
	public boolean estaDescubierta() {
		//Si el estado es descubierta, devuelve verdadero.
		if(estado == Estado.DESCUBIERTA) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Método que comprueba que el estado de la celda es marcada.
	 * 
	 * @return true si lo está o false si no
	 */
	public boolean estaMarcada() {
		//Si el estado es marcada, devuelve verdadero.
		if(estado == Estado.MARCADA) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Método que comprueba que el estado de la celda es oculta.
	 * 
	 * @return true si lo está o false si no
	 */
	public boolean estaOculta() {
		//Si el estado es oculta, devuelve verdadero.
		if(estado == Estado.OCULTA) {
			return true;
		}else {
			return false;
		}
		
	}
	
	/**
	 * Método que obtiene la columna.
	 * 
	 * @return columna
	 */
	public int obtenerColumna() {
		return columna;
	}
	
	/**
	 * Método que obtiene la fila.
	 * 
	 * @return fila
	 */
	public int obtenerFila() {
		return fila;
	}
	
	/**
	 * Método que obtiene el número de minas adyacentes.
	 * 
	 * @return numeroMinasAdy
	 */
	public int obtenerNumeroMinasAdyacentes() {
		return numeroMinasAdy;
	}
	
	/**
	 * Método que genera una cadena de texto del estado.
	 * 
	 * @return TEXTO_MINA
	 */
	public String obtenerTextoEstado() {
		if(estaDescubierta()) {
			if(tieneMina()) {
				return TEXTO_MINA;
			}else if(obtenerNumeroMinasAdyacentes() != 0){
				int X = obtenerNumeroMinasAdyacentes();
				return " " + X +" ";
			}else{
				return " . ";
			}
		}else {
			if(estaMarcada()) {
				return" P ";
			} else {
				return " - ";
			}
		}
	}
	
	/**
	 * Método que obtiene en cadena de texto la solución.
	 * 
	 * @return TEXTO_MINA
	 */
	public String obtenerTextoSolucion() {
		if(tieneMina()) {
			return TEXTO_MINA;
		}else {
			if(obtenerNumeroMinasAdyacentes() != 0){
				int X = obtenerNumeroMinasAdyacentes();
				return " " + X +" ";
			}else  {
				return " - ";
			}
		}
	}
	
	/**
	 * Método que comprueba si dos celdas tienen mismas coordenadas.
	 * 
	 * @param celda celda
	 * @return true si las tienen o false si no
	 */
	public boolean tieneCoordenadasIguales(Celda celda) {
		//Comprueba si filas y columnas de dos celdas son iguales.
		if(celda.fila == this.fila && celda.columna == this.columna) {
    		return true;
    	}else {
    		return false;
    	}
	}
	
	/**
	 * Método que comprueba si una celda tiene mina.
	 * 
	 * @return true si tiene, false si no
	 */
	public boolean tieneMina() {
		//Al haber instanciado las minas como -1, si el valor que toma es ese, hay mina.
		if(numeroMinasAdy == -1) {
			return true;
		}else {
			return false;
		}
		
	}

	/**
	 * Método que devuelve una cadena de texto.
	 * 
	 * @return texto de coordenadas, número de minas adyacentes y estado de una celda
	 */
	public String toString() {
		return "["+"("+fila+","+columna+")"+"-"+obtenerNumeroMinasAdyacentes()+"-"+estado+"]";
	}

	/**
	 * Método que devuelve el estado.
	 * 
	 * @return estado
	 */
	private Estado obtenerEstado() {
		return estado;
	}

	/**
	 * Método hashcode de la celda.
	 * 
	 * @return result
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((celda == null) ? 0 : celda.hashCode());
		result = prime * result + columna;
		result = prime * result + ((estado == null) ? 0 : estado.hashCode());
		result = prime * result + fila;
		return result;
	}

	/**
	 * Método equals de la celda.
	 * 
	 * @param obj Object
	 * @return true or false
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Celda other = (Celda) obj;
		if (celda == null) {
			if (other.celda != null)
				return false;
		} else if (!celda.equals(other.celda))
			return false;
		if (columna != other.columna)
			return false;
		if (estado != other.estado)
			return false;
		if (fila != other.fila)
			return false;
		return true;
	}
	
}
