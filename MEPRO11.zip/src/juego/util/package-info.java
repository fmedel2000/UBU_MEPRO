/**
 * Clases de utilidad. Sentido y excepciones por coordenadas incorrectas.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.4
 */
package juego.util;