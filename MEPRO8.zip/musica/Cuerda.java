package musica;
/**
 * Cuerda
 * @author Francisco Medel Molinero
 *
 */
public class Cuerda extends Instrumento{
	//private float precio;
	
		public Cuerda(float precio) {
			super(precio);
			//this.precio=precio;
		}
		
		@Override
		public void tocar(Nota nota) {		
			System.out.printf("Cuerda.tocar(): %s%n", nota.toString());
		}

		@Override
		public String toString() {
			return "[" + this.consultarPrecio() +  ":Viento]";
		}
}
