package musica;

/**
 * Viento
 * @author Francisco Medel Molinero
 *
 */
public class Viento extends Instrumento {	
	
	//private float precio;
	
	public Viento(float precio) {
		super(precio);
		//this.precio=precio;
	}
	
	@Override
	public void tocar(Nota nota) {		
		System.out.printf("Viento.tocar(): %s%n", nota.toString());
	}

	@Override
	public String toString() {
		return "[" + this.consultarPrecio() +  ":Viento]";
	}
}
