package musica;
/**
 * Musical
 * @author Francisco Medel Molinero
 *
 */
public interface Musical {
	void tocar(Nota n);
}
