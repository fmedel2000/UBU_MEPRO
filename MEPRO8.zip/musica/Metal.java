package musica;
/**
 * Metal
 * @author Francisco Medel Molinero
 *
 */
public class Metal extends Instrumento{
	//private float precio;
	
		public Metal(float precio) {
			super(precio);
			//this.precio=precio;
		}
		
		@Override
		public void tocar(Nota nota) {		
			System.out.printf("Metal.tocar(): %s%n", nota.toString());
		}

		@Override
		public String toString() {
			return "[" + this.consultarPrecio() +  ":Viento]";
		}
}
