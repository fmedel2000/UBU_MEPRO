package musica;

/**
 * Nota.
 *
 * @author Francisco Medel & <a href="mailto:rmartico@ubu.es">Raúl Marticorena</a>
 * @version 1.0
 */
public enum Nota { 
    DO,
    RE,
    MI,
    FA,
    SOL,
    LA,
    SI;
} 