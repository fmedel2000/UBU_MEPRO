/**
 * Sesi�n 1
 * @author Francisco Medel Molinero
 * @version 1.0
 * */
public class HolaMundo{
	 public static void main(String[] args){
		System.out.println("Hola mundo");
	}
}