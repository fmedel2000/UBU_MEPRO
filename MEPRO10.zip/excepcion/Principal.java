package excepcion;

import java.util.Scanner;

/**
 * Principal.
 * 
 * @author <a href="mailto:rmartico@ubu.es">Raúl Marticorena</a>
 * @author Francisco Medel Molinero
 * @version 1.0
 */
public class Principal {

	/**
	 * Método raíz.
	 *
	 * @param args argumentos
	 * @throws RuntimeException error en tiempo de ejecución
	 */
	public static void main(String[] args) throws RuntimeException{//el throws es opcional en este caso
		// COMPLETAR SEGÚN INDICACIONES DEL ENUNCIADO
		Scanner scanner = null;
		try {
		scanner = new Scanner(System.in);
		String s = scanner.next();
		Conversor conversor = new Conversor();
		System.out.println(conversor.aMinusculas(s));
		System.out.println(conversor.aMayusculas(s));
		}		
//		catch(CException ex) {
//			System.out.println("Error del tipo CException");
//			System.err.println(ex.toString());
//		}
//		catch(BException ex) {
//			System.err.println("Error del tipo BException");
//			System.err.println(ex.toString());
//		}
		catch(Exception ex) {
			throw new RuntimeException("Error en tiempo de ejecucion", ex);
		}
		finally {
			if(scanner != null) 
			scanner.close();
		}
	}
}