/**
 * Paquete que valida y permite usar los objetos creados para jugar.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.4
 */
package juego.control;