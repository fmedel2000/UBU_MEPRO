package juego.control;

import juego.modelo.Celda;
import juego.modelo.Tablero;
import juego.util.CoordenadasIncorrectasException;

/**
 * Clase del árbitro inseguro, hija del árbitro abstracto.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.2
 */
public class ArbitroInseguro extends ArbitroAbstracto{
	
	/**
	 * Celdas.
	 */
	private Celda celda;
	
	/**
	 * Tablero.
	 */
	private Tablero tablero;
	
	/**
	 * Método constructor del árbitro inseguro.
	 * 
	 * @param tablero Tablero inicial 
	 */
	public ArbitroInseguro(Tablero tablero) {
		super(tablero);
		this.tablero = tablero;
	}

	/**
	 * Descubre celdas a partir de la celda indicada.
	 * 
	 * @param fila fila
	 * @param columna columna
	 * @throws CoordenadasIncorrectasException si las coordenadas están fuera del tablero
	 */
	@Override
	public void descubrir(int fila, int columna) throws CoordenadasIncorrectasException{
		try {
			if((columna >= 8 || columna < 0) || (fila >= 8 || fila < 0)) {
				throw new CoordenadasIncorrectasException("La celda no pertenece al tablero");
			}else {
				if(tablero.contarMinas() != 10) {
		            celda = tablero.clonarCelda(fila,columna);
		            //Colocamos las minas.
		            tablero.colocarMinas();
		        }
		        //Descubrimos.
		        tablero.descubrir(fila, columna);
			}
		}catch(CoordenadasIncorrectasException e) {
			throw new CoordenadasIncorrectasException("No se puede descubrir la celda",e);
		}
		
	}
}