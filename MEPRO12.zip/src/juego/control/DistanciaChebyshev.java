package juego.control;
import juego.modelo.Celda;

/**
 * Clase para calcular las distancias entre celdas.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.1
 */
public class DistanciaChebyshev{
	
	/**
	 * Método que calcula la distancia entre dos celdas.
	 * 
	 * @param origen celda origen
	 * @param elegida celda destino
	 * @return distancia distancia de chebyshev
	 */
	public int calcular(Celda origen, Celda elegida) {
		
		int distancia = 0;
		distancia = Math.max(Math.abs(elegida.obtenerFila()-origen.obtenerFila()), Math.abs(elegida.obtenerColumna()-origen.obtenerColumna()));
		return distancia;
	}
}