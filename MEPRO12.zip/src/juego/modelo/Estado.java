package juego.modelo;
/**
 * Clase de los estados de las celdas del juego.
 * 
 * @author Francisco Medel, Alex Tomé
 * @since JDK 11
 * @version 1.0
 */
public enum Estado {
	/**Marcada. */
	MARCADA('P'), 
	/**Descubierta. */
	DESCUBIERTA('0'), 
	/**Oculta. */
	OCULTA('-');
	
	/**
	 * Letra.
	 */
	private char letra;
	
	/**
	 * Método constructor del estado.
	 * 
	 * @param letra letra
	 */
	private Estado(char letra) {
		this.letra = letra;
	}
	
	/**
	 * Método que obtiene la letra.
	 * 
	 * @return letra
	 */
	public char obtenerLetra() {
		return letra;
	}
}
